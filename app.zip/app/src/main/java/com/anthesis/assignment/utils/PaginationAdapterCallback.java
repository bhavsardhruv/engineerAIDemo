package com.anthesis.assignment.utils;

public interface PaginationAdapterCallback {
    void retryPageLoad();
}
