package com.anthesis.assignment.utils;

public interface Constant {
    String LIVE = "https://hn.algolia.com/";
    String DOMAIN = LIVE;
    String API_BASE_URL = DOMAIN + "api/";

}
