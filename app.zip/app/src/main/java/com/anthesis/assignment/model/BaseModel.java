package com.anthesis.assignment.model;

public class BaseModel {
}
